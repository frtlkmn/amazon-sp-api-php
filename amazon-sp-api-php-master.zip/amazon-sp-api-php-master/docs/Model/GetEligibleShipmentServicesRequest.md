# GetEligibleShipmentServicesRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shipment_request_details** | [**\Swagger\Client\Models\ShipmentRequestDetails**](ShipmentRequestDetails.md) |  | 
**shipping_offering_filter** | [**\Swagger\Client\Models\ShippingOfferingFilter**](ShippingOfferingFilter.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

