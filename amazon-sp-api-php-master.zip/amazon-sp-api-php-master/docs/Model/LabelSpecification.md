# LabelSpecification

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label_format** | **string** | The format of the label. Enum of PNG only for now. | 
**label_stock_size** | **string** | The label stock size specification in length and height. Enum of 4x6 only for now. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

