# BuyerCustomizedInfoDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**customized_url** | **string** | The location of a zip file containing Amazon Custom data. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

