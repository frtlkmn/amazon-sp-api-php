# GetEligibleShipmentServicesResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shipping_service_list** | [**\Swagger\Client\Models\ShippingServiceList**](ShippingServiceList.md) |  | 
**rejected_shipping_service_list** | [**\Swagger\Client\Models\RejectedShippingServiceList**](RejectedShippingServiceList.md) |  | [optional] 
**temporarily_unavailable_carrier_list** | [**\Swagger\Client\Models\TemporarilyUnavailableCarrierList**](TemporarilyUnavailableCarrierList.md) |  | [optional] 
**terms_and_conditions_not_accepted_carrier_list** | [**\Swagger\Client\Models\TermsAndConditionsNotAcceptedCarrierList**](TermsAndConditionsNotAcceptedCarrierList.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

