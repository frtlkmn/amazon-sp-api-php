# Points

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**points_number** | **int** | The number of points. | [optional] 
**points_monetary_value** | [**\Swagger\Client\Models\MoneyType**](MoneyType.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

