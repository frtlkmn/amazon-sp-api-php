# GetAdditionalSellerInputsResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shipment_level_fields** | [**\Swagger\Client\Models\AdditionalInputsList**](AdditionalInputsList.md) |  | [optional] 
**item_level_fields_list** | [**\Swagger\Client\Models\ItemLevelFieldsList**](ItemLevelFieldsList.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

