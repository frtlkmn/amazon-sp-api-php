# CreateInboundShipmentPlanResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inbound_shipment_plans** | [**\Swagger\Client\Models\InboundShipmentPlanList**](InboundShipmentPlanList.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

