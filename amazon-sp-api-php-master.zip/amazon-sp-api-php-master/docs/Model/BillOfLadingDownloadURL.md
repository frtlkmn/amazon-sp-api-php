# BillOfLadingDownloadURL

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**download_url** | **string** | URL to download the bill of lading for the package. Note: The URL will only be valid for 15 seconds | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

