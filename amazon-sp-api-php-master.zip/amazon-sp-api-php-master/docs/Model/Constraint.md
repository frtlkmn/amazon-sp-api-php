# Constraint

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**validation_reg_ex** | **string** | A regular expression. | [optional] 
**validation_string** | **string** | A validation string. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

