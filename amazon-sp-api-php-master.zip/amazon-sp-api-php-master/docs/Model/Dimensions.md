# Dimensions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**length** | **float** | The length of the container. | 
**width** | **float** | The width of the container. | 
**height** | **float** | The height of the container. | 
**unit** | **string** | The unit of these measurements. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

