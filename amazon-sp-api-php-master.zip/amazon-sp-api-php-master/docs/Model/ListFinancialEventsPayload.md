# ListFinancialEventsPayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**next_token** | **string** | When present and not empty, pass this string token in the next request to return the next response page. | [optional] 
**financial_events** | [**\Swagger\Client\Models\FinancialEvents**](FinancialEvents.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

