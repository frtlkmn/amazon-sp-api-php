# NonPartneredLtlDataOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**carrier_name** | **string** | The carrier that you are using for the inbound shipment. | 
**pro_number** | [**\Swagger\Client\Models\ProNumber**](ProNumber.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

