# MarketplaceParticipation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**marketplace** | [**\Swagger\Client\Models\Marketplace**](Marketplace.md) |  | 
**participation** | [**\Swagger\Client\Models\Participation**](Participation.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

