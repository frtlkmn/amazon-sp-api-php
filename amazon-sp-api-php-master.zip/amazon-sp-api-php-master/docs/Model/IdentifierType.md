# IdentifierType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**marketplace_asin** | [**\Swagger\Client\Models\ASINIdentifier**](ASINIdentifier.md) |  | 
**sku_identifier** | [**\Swagger\Client\Models\SellerSKUIdentifier**](SellerSKUIdentifier.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

