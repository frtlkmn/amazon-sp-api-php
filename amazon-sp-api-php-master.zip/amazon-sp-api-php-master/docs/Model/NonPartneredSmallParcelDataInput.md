# NonPartneredSmallParcelDataInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**carrier_name** | **string** | The carrier that you are using for the inbound shipment. | 
**package_list** | [**\Swagger\Client\Models\NonPartneredSmallParcelPackageInputList**](NonPartneredSmallParcelPackageInputList.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

