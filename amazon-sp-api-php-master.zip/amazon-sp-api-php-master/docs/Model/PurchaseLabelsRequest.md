# PurchaseLabelsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rate_id** | [**\Swagger\Client\Models\RateId**](RateId.md) |  | 
**label_specification** | [**\Swagger\Client\Models\LabelSpecification**](LabelSpecification.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

