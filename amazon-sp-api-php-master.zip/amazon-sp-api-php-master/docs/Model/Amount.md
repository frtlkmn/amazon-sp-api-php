# Amount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency_code** | [**\Swagger\Client\Models\CurrencyCode**](CurrencyCode.md) |  | 
**value** | [**\Swagger\Client\Models\BigDecimalType**](BigDecimalType.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

