# CreateFulfillmentReturnResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**return_item_list** | [**\Swagger\Client\Models\ReturnItemList**](ReturnItemList.md) |  | [optional] 
**invalid_return_item_list** | [**\Swagger\Client\Models\InvalidReturnItemList**](InvalidReturnItemList.md) |  | [optional] 
**return_authorization_list** | [**\Swagger\Client\Models\ReturnAuthorizationList**](ReturnAuthorizationList.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

