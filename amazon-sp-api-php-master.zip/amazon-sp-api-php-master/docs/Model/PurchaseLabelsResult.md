# PurchaseLabelsResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shipment_id** | [**\Swagger\Client\Models\ShipmentId**](ShipmentId.md) |  | 
**client_reference_id** | [**\Swagger\Client\Models\ClientReferenceId**](ClientReferenceId.md) |  | [optional] 
**accepted_rate** | [**\Swagger\Client\Models\AcceptedRate**](AcceptedRate.md) |  | 
**label_results** | [**\Swagger\Client\Models\LabelResultList**](LabelResultList.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

