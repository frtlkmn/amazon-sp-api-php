# LoanServicingEvent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loan_amount** | [**\Swagger\Client\Models\Currency**](Currency.md) |  | [optional] 
**source_business_event_type** | **string** | The type of event.  Possible values:  * LoanAdvance  * LoanPayment  * LoanRefund | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

