# PartneredLtlDataInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contact** | [**\Swagger\Client\Models\Contact**](Contact.md) |  | [optional] 
**box_count** | [**\Swagger\Client\Models\UnsignedIntType**](UnsignedIntType.md) |  | [optional] 
**seller_freight_class** | [**\Swagger\Client\Models\SellerFreightClass**](SellerFreightClass.md) |  | [optional] 
**freight_ready_date** | [**\Swagger\Client\Models\DateStringType**](DateStringType.md) |  | [optional] 
**pallet_list** | [**\Swagger\Client\Models\PalletList**](PalletList.md) |  | [optional] 
**total_weight** | [**\Swagger\Client\Models\Weight**](Weight.md) |  | [optional] 
**seller_declared_value** | [**\Swagger\Client\Models\Amount**](Amount.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

