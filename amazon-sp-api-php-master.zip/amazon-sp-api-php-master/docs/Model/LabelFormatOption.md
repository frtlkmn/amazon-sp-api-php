# LabelFormatOption

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**include_packing_slip_with_label** | **bool** | When true, include a packing slip with the label. | [optional] 
**label_format** | [**\Swagger\Client\Models\LabelFormat**](LabelFormat.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

