# CreateFeedDocumentSpecification

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content_type** | **string** | The content type of the feed. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

