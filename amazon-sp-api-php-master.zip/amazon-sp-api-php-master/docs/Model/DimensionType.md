# DimensionType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**height** | [**\Swagger\Client\Models\DecimalWithUnits**](DecimalWithUnits.md) |  | [optional] 
**length** | [**\Swagger\Client\Models\DecimalWithUnits**](DecimalWithUnits.md) |  | [optional] 
**width** | [**\Swagger\Client\Models\DecimalWithUnits**](DecimalWithUnits.md) |  | [optional] 
**weight** | [**\Swagger\Client\Models\DecimalWithUnits**](DecimalWithUnits.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

