# AvailableDeliveryExperienceOption

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**delivery_experience_option** | [**\Swagger\Client\Models\DeliveryExperienceOption**](DeliveryExperienceOption.md) |  | 
**charge** | [**\Swagger\Client\Models\CurrencyAmount**](CurrencyAmount.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

