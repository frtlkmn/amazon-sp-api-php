# ListReturnReasonCodesResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reason_code_details_list** | [**\Swagger\Client\Models\ReasonCodeDetailsList**](ReasonCodeDetailsList.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

