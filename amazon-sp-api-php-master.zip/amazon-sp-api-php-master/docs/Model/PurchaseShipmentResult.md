# PurchaseShipmentResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shipment_id** | [**\Swagger\Client\Models\ShipmentId**](ShipmentId.md) |  | 
**service_rate** | [**\Swagger\Client\Models\ServiceRate**](ServiceRate.md) |  | 
**label_results** | [**\Swagger\Client\Models\LabelResultList**](LabelResultList.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

