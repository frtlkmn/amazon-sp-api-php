# PartneredSmallParcelDataOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**package_list** | [**\Swagger\Client\Models\PartneredSmallParcelPackageOutputList**](PartneredSmallParcelPackageOutputList.md) |  | 
**partnered_estimate** | [**\Swagger\Client\Models\PartneredEstimate**](PartneredEstimate.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

