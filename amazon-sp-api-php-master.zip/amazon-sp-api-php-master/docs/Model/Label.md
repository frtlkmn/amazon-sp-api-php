# Label

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label_stream** | [**\Swagger\Client\Models\LabelStream**](LabelStream.md) |  | [optional] 
**label_specification** | [**\Swagger\Client\Models\LabelSpecification**](LabelSpecification.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

