# LabelResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**container_reference_id** | [**\Swagger\Client\Models\ContainerReferenceId**](ContainerReferenceId.md) |  | [optional] 
**tracking_id** | **string** | The tracking identifier assigned to the container. | [optional] 
**label** | [**\Swagger\Client\Models\Label**](Label.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

