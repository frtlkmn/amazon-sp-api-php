# GetRatesResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**service_rates** | [**\Swagger\Client\Models\ServiceRateList**](ServiceRateList.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

