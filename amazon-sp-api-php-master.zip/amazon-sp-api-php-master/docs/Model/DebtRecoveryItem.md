# DebtRecoveryItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recovery_amount** | [**\Swagger\Client\Models\Currency**](Currency.md) |  | [optional] 
**original_amount** | [**\Swagger\Client\Models\Currency**](Currency.md) |  | [optional] 
**group_begin_date** | [**\Swagger\Client\Models\\DateTime**](\DateTime.md) |  | [optional] 
**group_end_date** | [**\Swagger\Client\Models\\DateTime**](\DateTime.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

