# CompetitivePricingType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**competitive_prices** | [**\Swagger\Client\Models\CompetitivePriceList**](CompetitivePriceList.md) |  | 
**number_of_offer_listings** | [**\Swagger\Client\Models\NumberOfOfferListingsList**](NumberOfOfferListingsList.md) |  | 
**trade_in_value** | [**\Swagger\Client\Models\MoneyType**](MoneyType.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

