# CreateShipmentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**client_reference_id** | [**\Swagger\Client\Models\ClientReferenceId**](ClientReferenceId.md) |  | 
**ship_to** | [**\Swagger\Client\Models\Address**](Address.md) |  | 
**ship_from** | [**\Swagger\Client\Models\Address**](Address.md) |  | 
**containers** | [**\Swagger\Client\Models\ContainerList**](ContainerList.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

