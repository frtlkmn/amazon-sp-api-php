# PartneredEstimate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | [**\Swagger\Client\Models\Amount**](Amount.md) |  | 
**confirm_deadline** | [**\Swagger\Client\Models\TimeStampStringType**](TimeStampStringType.md) |  | [optional] 
**void_deadline** | [**\Swagger\Client\Models\TimeStampStringType**](TimeStampStringType.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

