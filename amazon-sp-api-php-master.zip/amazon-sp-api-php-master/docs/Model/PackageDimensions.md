# PackageDimensions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**length** | [**\Swagger\Client\Models\PackageDimension**](PackageDimension.md) |  | [optional] 
**width** | [**\Swagger\Client\Models\PackageDimension**](PackageDimension.md) |  | [optional] 
**height** | [**\Swagger\Client\Models\PackageDimension**](PackageDimension.md) |  | [optional] 
**unit** | [**\Swagger\Client\Models\UnitOfLength**](UnitOfLength.md) |  | [optional] 
**predefined_package_dimensions** | [**\Swagger\Client\Models\PredefinedPackageDimensions**](PredefinedPackageDimensions.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

