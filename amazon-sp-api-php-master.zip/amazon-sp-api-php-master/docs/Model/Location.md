# Location

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**state_or_region** | [**\Swagger\Client\Models\StateOrRegion**](StateOrRegion.md) |  | [optional] 
**city** | [**\Swagger\Client\Models\City**](City.md) |  | [optional] 
**country_code** | [**\Swagger\Client\Models\CountryCode**](CountryCode.md) |  | [optional] 
**postal_code** | [**\Swagger\Client\Models\PostalCode**](PostalCode.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

