# Participation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_participating** | **bool** |  | 
**has_suspended_listings** | **bool** | Specifies if the seller has suspended listings. True if the seller Listing Status is set to Inactive, otherwise False. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

