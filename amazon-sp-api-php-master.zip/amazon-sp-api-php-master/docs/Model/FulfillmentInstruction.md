# FulfillmentInstruction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fulfillment_supply_source_id** | **string** | Denotes the recommended sourceId where the order should be fulfilled from. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

