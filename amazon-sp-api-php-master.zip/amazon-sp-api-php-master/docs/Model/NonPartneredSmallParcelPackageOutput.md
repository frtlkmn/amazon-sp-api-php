# NonPartneredSmallParcelPackageOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**carrier_name** | **string** | The carrier that you are using for the inbound shipment. | 
**tracking_id** | [**\Swagger\Client\Models\TrackingId**](TrackingId.md) |  | 
**package_status** | [**\Swagger\Client\Models\PackageStatus**](PackageStatus.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

