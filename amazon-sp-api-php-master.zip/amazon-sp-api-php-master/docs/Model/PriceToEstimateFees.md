# PriceToEstimateFees

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**listing_price** | [**\Swagger\Client\Models\MoneyType**](MoneyType.md) |  | 
**shipping** | [**\Swagger\Client\Models\MoneyType**](MoneyType.md) |  | [optional] 
**points** | [**\Swagger\Client\Models\Points**](Points.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

