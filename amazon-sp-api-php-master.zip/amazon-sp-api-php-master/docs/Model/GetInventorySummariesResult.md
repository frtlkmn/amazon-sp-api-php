# GetInventorySummariesResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**granularity** | [**\Swagger\Client\Models\Granularity**](Granularity.md) |  | 
**inventory_summaries** | [**\Swagger\Client\Models\InventorySummaries**](InventorySummaries.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

