# GetTransportDetailsResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transport_content** | [**\Swagger\Client\Models\TransportContent**](TransportContent.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

