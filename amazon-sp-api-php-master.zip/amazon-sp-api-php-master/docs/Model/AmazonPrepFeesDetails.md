# AmazonPrepFeesDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**prep_instruction** | [**\Swagger\Client\Models\PrepInstruction**](PrepInstruction.md) |  | [optional] 
**fee_per_unit** | [**\Swagger\Client\Models\Amount**](Amount.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

