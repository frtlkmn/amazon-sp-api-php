# DestinationResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sqs** | [**\Swagger\Client\Models\SqsResource**](SqsResource.md) |  | [optional] 
**event_bridge** | [**\Swagger\Client\Models\EventBridgeResource**](EventBridgeResource.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

