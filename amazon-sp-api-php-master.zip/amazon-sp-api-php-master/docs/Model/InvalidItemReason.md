# InvalidItemReason

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**invalid_item_reason_code** | [**\Swagger\Client\Models\InvalidItemReasonCode**](InvalidItemReasonCode.md) |  | 
**description** | **string** | A human readable description of the invalid item reason code. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

