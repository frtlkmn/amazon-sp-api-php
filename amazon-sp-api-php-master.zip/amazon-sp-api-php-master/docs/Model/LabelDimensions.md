# LabelDimensions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**length** | [**\Swagger\Client\Models\LabelDimension**](LabelDimension.md) |  | 
**width** | [**\Swagger\Client\Models\LabelDimension**](LabelDimension.md) |  | 
**unit** | [**\Swagger\Client\Models\UnitOfLength**](UnitOfLength.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

