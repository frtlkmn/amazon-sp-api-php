# AvailableCarrierWillPickUpOption

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**carrier_will_pick_up_option** | [**\Swagger\Client\Models\CarrierWillPickUpOption**](CarrierWillPickUpOption.md) |  | 
**charge** | [**\Swagger\Client\Models\CurrencyAmount**](CurrencyAmount.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

