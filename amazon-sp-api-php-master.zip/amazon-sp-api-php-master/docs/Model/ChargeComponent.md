# ChargeComponent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**charge_type** | **string** | The type of charge. | [optional] 
**charge_amount** | [**\Swagger\Client\Models\Currency**](Currency.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

