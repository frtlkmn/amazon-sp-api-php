# BoxContentsFeeDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_units** | [**\Swagger\Client\Models\Quantity**](Quantity.md) |  | [optional] 
**fee_per_unit** | [**\Swagger\Client\Models\Amount**](Amount.md) |  | [optional] 
**total_fee** | [**\Swagger\Client\Models\Amount**](Amount.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

