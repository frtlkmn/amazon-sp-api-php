# GetFulfillmentOrderResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fulfillment_order** | [**\Swagger\Client\Models\FulfillmentOrder**](FulfillmentOrder.md) |  | 
**fulfillment_order_item** | [**\Swagger\Client\Models\FulfillmentOrderItemList**](FulfillmentOrderItemList.md) |  | 
**fulfillment_shipment** | [**\Swagger\Client\Models\FulfillmentShipmentList**](FulfillmentShipmentList.md) |  | [optional] 
**return_item_list** | [**\Swagger\Client\Models\ReturnItemList**](ReturnItemList.md) |  | 
**return_authorization_list** | [**\Swagger\Client\Models\ReturnAuthorizationList**](ReturnAuthorizationList.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

