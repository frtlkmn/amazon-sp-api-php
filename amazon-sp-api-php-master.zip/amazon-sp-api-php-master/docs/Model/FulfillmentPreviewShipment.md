# FulfillmentPreviewShipment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**earliest_ship_date** | [**\Swagger\Client\Models\Timestamp**](Timestamp.md) |  | 
**latest_ship_date** | [**\Swagger\Client\Models\Timestamp**](Timestamp.md) |  | 
**earliest_arrival_date** | [**\Swagger\Client\Models\Timestamp**](Timestamp.md) |  | 
**latest_arrival_date** | [**\Swagger\Client\Models\Timestamp**](Timestamp.md) |  | 
**fulfillment_preview_items** | [**\Swagger\Client\Models\FulfillmentPreviewItemList**](FulfillmentPreviewItemList.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

