# ConfirmPreorderResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**confirmed_need_by_date** | [**\Swagger\Client\Models\DateStringType**](DateStringType.md) |  | [optional] 
**confirmed_fulfillable_date** | [**\Swagger\Client\Models\DateStringType**](DateStringType.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

