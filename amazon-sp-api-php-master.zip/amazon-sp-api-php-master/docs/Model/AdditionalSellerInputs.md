# AdditionalSellerInputs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**additional_input_field_name** | **string** | The name of the additional input field. | 
**additional_seller_input** | [**\Swagger\Client\Models\AdditionalSellerInput**](AdditionalSellerInput.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

