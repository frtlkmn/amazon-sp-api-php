# GetInboundGuidanceResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sku_inbound_guidance_list** | [**\Swagger\Client\Models\SKUInboundGuidanceList**](SKUInboundGuidanceList.md) |  | [optional] 
**invalid_sku_list** | [**\Swagger\Client\Models\InvalidSKUList**](InvalidSKUList.md) |  | [optional] 
**asin_inbound_guidance_list** | [**\Swagger\Client\Models\ASINInboundGuidanceList**](ASINInboundGuidanceList.md) |  | [optional] 
**invalid_asin_list** | [**\Swagger\Client\Models\InvalidASINList**](InvalidASINList.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

