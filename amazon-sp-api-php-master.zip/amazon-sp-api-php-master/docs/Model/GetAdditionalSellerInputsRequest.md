# GetAdditionalSellerInputsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shipping_service_id** | [**\Swagger\Client\Models\ShippingServiceIdentifier**](ShippingServiceIdentifier.md) |  | 
**ship_from_address** | [**\Swagger\Client\Models\Address**](Address.md) |  | 
**order_id** | [**\Swagger\Client\Models\AmazonOrderId**](AmazonOrderId.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

