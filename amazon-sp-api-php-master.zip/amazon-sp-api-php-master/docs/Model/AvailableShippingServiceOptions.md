# AvailableShippingServiceOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available_carrier_will_pick_up_options** | [**\Swagger\Client\Models\AvailableCarrierWillPickUpOptionsList**](AvailableCarrierWillPickUpOptionsList.md) |  | 
**available_delivery_experience_options** | [**\Swagger\Client\Models\AvailableDeliveryExperienceOptionsList**](AvailableDeliveryExperienceOptionsList.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

