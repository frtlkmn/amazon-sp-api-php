# GetServiceJobsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | [**\Swagger\Client\Models\JobListing**](JobListing.md) |  | [optional] 
**errors** | [**\Swagger\Client\Models\ErrorList**](ErrorList.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

