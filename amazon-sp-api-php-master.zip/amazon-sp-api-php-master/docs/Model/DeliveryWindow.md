# DeliveryWindow

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_date_time** | [**\Swagger\Client\Models\Timestamp**](Timestamp.md) |  | 
**end_date_time** | [**\Swagger\Client\Models\Timestamp**](Timestamp.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

