# FeeLineItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fee_type** | **string** | The type of fee charged to the seller. | 
**fee_charge** | [**\Swagger\Client\Models\MoneyType**](MoneyType.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

