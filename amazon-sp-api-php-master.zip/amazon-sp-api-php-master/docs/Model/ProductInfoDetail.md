# ProductInfoDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number_of_items** | **int** | The total number of items that are included in the ASIN. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

