# GetSolicitationActionsForOrderResponseLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | [**\Swagger\Client\Models\LinkObject**](LinkObject.md) |  | 
**actions** | [**\Swagger\Client\Models\LinkObject[]**](LinkObject.md) | Eligible actions for the specified amazonOrderId. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

