# CreateDestinationRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resource_specification** | [**\Swagger\Client\Models\DestinationResourceSpecification**](DestinationResourceSpecification.md) |  | 
**name** | **string** | A developer-defined name to help identify this destination. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

