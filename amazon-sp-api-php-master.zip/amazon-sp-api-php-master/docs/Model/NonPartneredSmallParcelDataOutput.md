# NonPartneredSmallParcelDataOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**package_list** | [**\Swagger\Client\Models\NonPartneredSmallParcelPackageOutputList**](NonPartneredSmallParcelPackageOutputList.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

