# LabelCustomization

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**custom_text_for_label** | [**\Swagger\Client\Models\CustomTextForLabel**](CustomTextForLabel.md) |  | [optional] 
**standard_id_for_label** | [**\Swagger\Client\Models\StandardIdForLabel**](StandardIdForLabel.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

