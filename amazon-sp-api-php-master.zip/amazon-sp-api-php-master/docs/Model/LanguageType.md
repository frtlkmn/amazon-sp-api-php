# LanguageType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | The name attribute of the item. | [optional] 
**type** | **string** | The type attribute of the item. | [optional] 
**audio_format** | **string** | The audio format attribute of the item. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

